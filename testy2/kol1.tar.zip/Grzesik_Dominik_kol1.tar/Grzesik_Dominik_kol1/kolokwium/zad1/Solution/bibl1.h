#pragma once
  extern int fun1(int a, int b);
  extern int fun2(int a, int b);
